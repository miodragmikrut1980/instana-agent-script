/*
(c) Copyright IBM Corp. 2026

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllers

import (
	"context"
	"fmt"
	"sort"

	"github.com/go-logr/logr"
	corev1 "k8s.io/api/core/v1"
	discoveryv1 "k8s.io/api/discovery/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	"sigs.k8s.io/controller-runtime/pkg/client"

	instanav1 "github.com/instana/instana-agent-operator/api/v1"
	instanaclient "github.com/instana/instana-agent-operator/pkg/k8s/client"
	"github.com/instana/instana-agent-operator/pkg/k8s/object/builders/common/constants"
	"github.com/instana/instana-agent-operator/pkg/k8s/operator/operator_utils"
)

// ETCDDiscoverer defines the interface for ETCD discovery operations
type ETCDDiscoverer interface {
	// ShouldSkipDiscovery checks if ETCD discovery should be skipped
	ShouldSkipDiscovery(ctx context.Context, agent *instanav1.InstanaAgent) (bool, error)

	// FindETCDService attempts to find an etcd service in the kube-system namespace
	FindETCDService(ctx context.Context, log logr.Logger) (*corev1.Service, error)

	// GetServiceWithLabel gets a service with the specified name and checks if it has the expected label
	GetServiceWithLabel(
		ctx context.Context,
		name, labelKey, labelValue string,
	) (*corev1.Service, error)

	// GetServiceByName gets a service by name
	GetServiceByName(ctx context.Context, name string) (*corev1.Service, error)

	// FindMetricsPortAndScheme finds the metrics port and determines the scheme
	FindMetricsPortAndScheme(service *corev1.Service) (*int32, string)

	// BuildTargetsFromEndpoints builds targets from service endpoint slices
	BuildTargetsFromEndpoints(
		ctx context.Context,
		service *corev1.Service,
		metricsPort int32,
		scheme string,
	) ([]string, error)

	// BuildTargetsFromLegacyEndpoints builds targets from legacy Endpoints resource
	BuildTargetsFromLegacyEndpoints(
		ctx context.Context,
		service *corev1.Service,
		metricsPort int32,
		scheme string,
	) ([]string, error)

	// CheckCASecretExists checks if the etcd-ca secret exists in the agent namespace
	CheckCASecretExists(ctx context.Context, agent *instanav1.InstanaAgent) bool
}

// DefaultETCDDiscoverer is the production implementation of ETCDDiscoverer
type DefaultETCDDiscoverer struct {
	client     instanaclient.InstanaAgentClient
	reconciler *InstanaAgentReconciler
}

// NewDefaultETCDDiscoverer creates a new DefaultETCDDiscoverer instance
func NewDefaultETCDDiscoverer(
	client instanaclient.InstanaAgentClient,
	reconciler *InstanaAgentReconciler,
) *DefaultETCDDiscoverer {
	return &DefaultETCDDiscoverer{
		client:     client,
		reconciler: reconciler,
	}
}

// ShouldSkipDiscovery checks if ETCD discovery should be skipped
func (d *DefaultETCDDiscoverer) ShouldSkipDiscovery(
	ctx context.Context,
	agent *instanav1.InstanaAgent,
) (bool, error) {
	operatorUtils := operator_utils.NewOperatorUtils(ctx, d.client, agent, nil)
	isOpenShift, isOpenShiftRes := d.reconciler.isOpenShift(ctx, operatorUtils)

	if isOpenShiftRes.suppliesReconcileResult() {
		return false, fmt.Errorf("failed to determine if cluster is OpenShift")
	}

	if isOpenShift {
		d.reconciler.loggerFor(ctx, agent).Info("Skipping ETCD discovery on OpenShift cluster")
		return true, nil
	}

	// Targets on the CR used to short circuit discovery, back when they were handed to
	// the k8sensor as ETCD_TARGETS. They are ignored now, and discovery still has to run
	// to find the CA, so a deprecated field must not suppress it.

	return false, nil
}

// FindETCDService attempts to find an etcd service in the kube-system namespace
func (d *DefaultETCDDiscoverer) FindETCDService(
	ctx context.Context,
	log logr.Logger,
) (*corev1.Service, error) {
	// Try services with component=etcd label first
	if service, err := d.GetServiceWithLabel(ctx, "etcd", "component", "etcd"); err != nil {
		return nil, err
	} else if service != nil {
		log.Info("Found etcd service with component=etcd label", "name", service.Name)
		return service, nil
	}

	if service, err := d.GetServiceWithLabel(ctx, "etcd-metrics", "component", "etcd"); err != nil {
		return nil, err
	} else if service != nil {
		log.Info("Found etcd-metrics service with component=etcd label", "name", service.Name)
		return service, nil
	}

	// Fallback to name-based search
	log.Info("No service found with component=etcd label, trying by name")

	// Try by name in sequence
	serviceNames := []string{"etcd", "etcd-metrics", "etcd-k8s"}
	for _, name := range serviceNames {
		service, err := d.GetServiceByName(ctx, name)
		if err != nil {
			return nil, err
		}
		if service != nil {
			return service, nil
		}
	}

	return nil, nil
}

// GetServiceWithLabel gets a service with the specified name and checks if it has the expected label
func (d *DefaultETCDDiscoverer) GetServiceWithLabel(
	ctx context.Context,
	name, labelKey, labelValue string,
) (*corev1.Service, error) {
	service, err := d.GetServiceByName(ctx, name)
	if err != nil || service == nil {
		return service, err
	}

	if service.Labels == nil || service.Labels[labelKey] != labelValue {
		return nil, nil
	}

	return service, nil
}

// GetServiceByName gets a service by name
func (d *DefaultETCDDiscoverer) GetServiceByName(
	ctx context.Context,
	name string,
) (*corev1.Service, error) {
	service := &corev1.Service{}
	err := d.client.Get(ctx, client.ObjectKey{
		Namespace: kubeSystemNamespace,
		Name:      name,
	}, service)
	if err != nil {
		if errors.IsNotFound(err) {
			return nil, nil
		}
		return nil, err
	}

	return service, nil
}

// FindMetricsPortAndScheme finds the metrics port and determines the scheme
func (d *DefaultETCDDiscoverer) FindMetricsPortAndScheme(
	service *corev1.Service,
) (*int32, string) {
	for _, port := range service.Spec.Ports {
		if port.Name == "metrics" {
			// Use switch/case for scheme determination
			scheme := "https" // Default to https for unknown ports
			switch port.Port {
			case constants.ETCDMetricsPortHTTPS:
				scheme = "https"
			case constants.ETCDMetricsPortHTTP:
				scheme = "http"
			}

			// Check for scheme annotation override
			if schemeOverride, ok := service.Annotations["instana.io/etcd-scheme"]; ok {
				scheme = schemeOverride
			}

			return &port.Port, scheme
		}
	}

	return nil, ""
}

// BuildTargetsFromEndpoints builds targets from service endpoint slices
func (d *DefaultETCDDiscoverer) BuildTargetsFromEndpoints(
	ctx context.Context,
	service *corev1.Service,
	metricsPort int32,
	scheme string,
) ([]string, error) {
	// List endpoint slices belonging to the service. EndpointSlice names include a random
	// suffix, so we have to rely on the service label instead of the service name.
	endpointSlices := &discoveryv1.EndpointSliceList{}
	if err := d.client.List(
		ctx,
		endpointSlices,
		client.InNamespace(kubeSystemNamespace),
		client.MatchingLabels(map[string]string{discoveryv1.LabelServiceName: service.Name}),
	); err != nil {
		return nil, err
	}

	targets := make([]string, 0)

	for i := range endpointSlices.Items {
		sliceTargets := buildTargetsFromEndpointSlice(&endpointSlices.Items[i], metricsPort, scheme)
		targets = append(targets, sliceTargets...)
	}

	if len(targets) == 0 {
		legacyTargets, err := d.BuildTargetsFromLegacyEndpoints(ctx, service, metricsPort, scheme)
		if err != nil {
			return nil, err
		}
		targets = append(targets, legacyTargets...)
	}

	// Sort targets for consistent comparison with current state
	sort.Strings(targets)

	return targets, nil
}

// BuildTargetsFromLegacyEndpoints builds targets from legacy Endpoints resource
func (d *DefaultETCDDiscoverer) BuildTargetsFromLegacyEndpoints(
	ctx context.Context,
	service *corev1.Service,
	metricsPort int32,
	scheme string,
) ([]string, error) {
	endpoints := &corev1.Endpoints{}
	if err := d.client.Get(ctx, client.ObjectKey{
		Namespace: kubeSystemNamespace,
		Name:      service.Name,
	}, endpoints); err != nil {
		if errors.IsNotFound(err) {
			return []string{}, nil
		}
		return nil, err
	}

	targets := make([]string, 0)

	for _, subset := range endpoints.Subsets {
		endpointPort := metricsPort
		for _, port := range subset.Ports {
			if port.Name == "metrics" {
				endpointPort = port.Port
				break
			}
		}

		for _, address := range subset.Addresses {
			target := fmt.Sprintf("%s://%s:%d/metrics", scheme, address.IP, endpointPort)
			targets = append(targets, target)
		}
	}

	return targets, nil
}

// CheckCASecretExists checks if the etcd-ca secret exists in the agent namespace
func (d *DefaultETCDDiscoverer) CheckCASecretExists(
	ctx context.Context,
	agent *instanav1.InstanaAgent,
) bool {
	caSecret := &corev1.Secret{} // pragma: whitelist secret
	err := d.client.Get(ctx, client.ObjectKey{
		Namespace: agent.Namespace,
		Name:      constants.ETCDCASecretName,
	}, caSecret)

	if err == nil {
		d.reconciler.loggerFor(ctx, agent).Info("Found etcd-ca secret in agent namespace")
		return true
	}

	return false
}

func buildTargetsFromEndpointSlice(
	endpointSlice *discoveryv1.EndpointSlice,
	metricsPort int32,
	scheme string,
) []string {
	targets := make([]string, 0)

	// Find the metrics port in the endpoint slice
	endpointPort := metricsPort
	for _, port := range endpointSlice.Ports {
		if port.Name != nil && *port.Name == "metrics" && port.Port != nil {
			endpointPort = *port.Port
			break
		}
	}

	// Add targets for each ready endpoint
	for _, endpoint := range endpointSlice.Endpoints {
		// Skip if Ready is explicitly set to false
		// We don't need to check if endpoint.Conditions is nil (it can't be nil since it's a struct value),
		// but we should handle the case where endpoint.Conditions.Ready is nil, which according to the
		// documentation should be interpreted as "true"
		if endpoint.Conditions.Ready != nil && !*endpoint.Conditions.Ready {
			continue
		}
		for _, address := range endpoint.Addresses {
			target := fmt.Sprintf("%s://%s:%d/metrics", scheme, address, endpointPort)
			targets = append(targets, target)
		}
	}

	return targets
}
