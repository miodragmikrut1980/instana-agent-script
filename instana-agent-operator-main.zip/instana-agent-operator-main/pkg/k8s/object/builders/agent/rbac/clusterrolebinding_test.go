/*
(c) Copyright IBM Corp. 2025
(c) Copyright Instana Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package rbac

import (
	"testing"

	"github.com/instana/instana-agent-operator/internal/mocks"
	"github.com/instana/instana-agent-operator/pkg/k8s/object/builders/common/constants"
	"github.com/instana/instana-agent-operator/pkg/optional"
	"github.com/stretchr/testify/require"
	rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/rand"
	"sigs.k8s.io/controller-runtime/pkg/client"

	instanav1 "github.com/instana/instana-agent-operator/api/v1"
)

func TestClusterRoleBindingBuilder_IsNamespaced_ComponentName(t *testing.T) {
	assertions := require.New(t)

	crb := NewClusterRoleBindingBuilder(nil)

	assertions.False(crb.IsNamespaced())
	assertions.Equal(constants.ComponentInstanaAgent, crb.ComponentName())
}

func TestClusterRoleBindingBuilder_Build(t *testing.T) {
	assertions := require.New(t)

	clusterScopedName := rand.String(10)
	serviceAccountName := rand.String(10)
	namespace := rand.String(10)

	agent := &instanav1.InstanaAgent{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: namespace,
		},
	}

	expected := optional.Of[client.Object](
		&rbacv1.ClusterRoleBinding{
			TypeMeta: metav1.TypeMeta{
				APIVersion: "rbac.authorization.k8s.io/v1",
				Kind:       "ClusterRoleBinding",
			},
			ObjectMeta: metav1.ObjectMeta{
				Name: clusterScopedName,
			},
			RoleRef: rbacv1.RoleRef{
				APIGroup: "rbac.authorization.k8s.io",
				Kind:     "ClusterRole",
				Name:     clusterScopedName,
			},
			Subjects: []rbacv1.Subject{
				{
					Kind:      "ServiceAccount",
					Name:      serviceAccountName,
					Namespace: namespace,
				},
			},
		},
	)

	helpers := &mocks.MockHelpers{}
	defer helpers.AssertExpectations(t)
	helpers.On("ClusterScopedRBACName").Return(clusterScopedName).Times(2)
	helpers.On("ServiceAccountName").Return(serviceAccountName).Once()

	crb := &clusterRoleBindingBuilder{
		InstanaAgent: agent,
		Helpers:      helpers,
	}

	actual := crb.Build()

	assertions.Equal(expected, actual)
}
