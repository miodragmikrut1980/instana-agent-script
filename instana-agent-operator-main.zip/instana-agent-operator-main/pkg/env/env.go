/*
(c) Copyright IBM Corp. 2024
(c) Copyright Instana Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package env

import (
	"os"

	logf "sigs.k8s.io/controller-runtime/pkg/log"
)

var (
	operatorVersionEnvVarName = "OPERATOR_VERSION"
	fallbackOperatorVersion   = "v0.0.1-dev"
	log                       = logf.Log.WithName("env")
)

var (
	operatorNamespaceEnvVarName = "POD_NAMESPACE"
	defaultOperatorNamespace    = "instana-agent"
)

func GetOperatorVersion() string {
	if os.Getenv(operatorVersionEnvVarName) != "" {
		return os.Getenv(operatorVersionEnvVarName)
	}
	return fallbackOperatorVersion
}

// GetOperatorNamespace returns the namespace where the operator is running.
// It reads from POD_NAMESPACE environment variable, falling back to "instana-agent" if not set.
func GetOperatorNamespace() string {
	if ns := os.Getenv(operatorNamespaceEnvVarName); ns != "" {
		return ns
	}
	return defaultOperatorNamespace
}
